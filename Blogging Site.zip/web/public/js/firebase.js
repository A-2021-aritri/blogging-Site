// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
let firebaseConfig = {
  apiKey: "AIzaSyDfSuAs1eal1jYbBzFe7w9FwFc0q6GKAVY",
  authDomain: "blogging-site-6de57.firebaseapp.com",
  projectId: "blogging-site-6de57",
  storageBucket: "blogging-site-6de57.appspot.com",
  messagingSenderId: "830830125572",
  appId: "1:830830125572:web:b6f3b4ffe253f7c4cc0b51",
  measurementId: "G-DEKJL63YNT"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
let db=firebase.firestore();